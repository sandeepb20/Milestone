public static public class Test {
    int x = 1+2;
    // int a = 3 + 5 + x / 9 * 3 %4;
    int a = a+1;
    int c;
    int s; int p;
    int abc[][] = new int[3][4];
    int[][] xy = new int[3][3];
    private Test(int x, int y, int z){
        int al= kk;
        
    }
    int kk;
    public static void main(String[] args) {
        int i=1;
        Test obj = new Test(1,2, 5);
        obj.getdata(200, 100);
        obj.add();
    }
    private void getdata(int x, int y) {
        a = x;
        // b = y;
        int z = 1;
        for (int i = 0; i < 8; i++) {
            a = x;
            int f = z;
            while (b > 9) {
                int for2 = z;
            }
            int z;
        }
        for(a = 0;; a++)
            a++;
        if(a > 0){
            int a1 = 1;
        }
        else{
            int a2 = 1;
        }
    }

    void add() {
        char e = 'a';
    }

   
}


public class A{
	int foo(int a){
	  return a;
	}
	public void main(){
	  int k = foo(9);
	  int[][] c= new int[3][4];
	  int a1[] = new int[2], b1[] = new int[3], d1[] = new int[4];
	  int[][] a = new int[2][1], b = new int[3][1], d = new int[4][2];
	}
  }
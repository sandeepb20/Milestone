public class test_31 {
    public int add_num(int x, int y, int z){
        int c =x;
        int d = c;

        int e = c + d;
        return e;
    }
    public int main(){
        int a = 1;
        int b = 2;
        int c = add_num(a,b, 0);
        int d = 6;
        int k = add_num(c, d, 0);
        // print()
        return 0;
    }
}
